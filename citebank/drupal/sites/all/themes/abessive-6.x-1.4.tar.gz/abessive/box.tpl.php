<?php // $Id: box.tpl.php,v 1.1.2.1 2008/09/05 15:30:24 njt1982 Exp $ ?>
<div class="box">
  <?php if ($title): ?><h2 class="title"><?php print $title ?></h2><?php endif; ?>
  <div class="content"><?php print $content ?></div>
</div>
